package com.hadith.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;

public class HadithWidgetProvider extends AppWidgetProvider {

    static final String ACTION_NEXT = "com.hadith.widget.ACTION_NEXT";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) {
            update(context, manager, id);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent != null && ACTION_NEXT.equals(intent.getAction())) {
            HadithRepo.next(context);
            refreshAll(context);
        }
    }

    static void update(Context context, AppWidgetManager manager, int appWidgetId) {
        HadithRepo.Hadith h = HadithRepo.current(context);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_hadith);
        views.setTextViewText(R.id.hadith_text, "“" + h.text + "”");
        views.setTextViewText(R.id.hadith_source, h.narrator + " • " + h.source);

        Intent intent = new Intent(context, HadithWidgetProvider.class);
        intent.setAction(ACTION_NEXT);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getBroadcast(context, 0, intent, flags);
        views.setOnClickPendingIntent(R.id.widget_root, pi);

        manager.updateAppWidget(appWidgetId, views);
    }

    static void refreshAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, HadithWidgetProvider.class));
        for (int id : ids) {
            update(context, manager, id);
        }
    }
}
