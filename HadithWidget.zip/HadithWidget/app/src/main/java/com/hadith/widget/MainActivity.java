package com.hadith.widget;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = (int) (16 * getResources().getDisplayMetrics().density);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        root.addView(text("ইসলামিক হাদিস উইজেট", 22, true, 0));
        root.addView(text(
                "কীভাবে ব্যবহার করবেন:\n"
                        + "১. হোম স্ক্রিনের ফাঁকা জায়গায় কিছুক্ষণ চেপে ধরুন\n"
                        + "২. “উইজেট” নির্বাচন করুন\n"
                        + "৩. “হাদিস উইজেট” খুঁজে হোম স্ক্রিনে বসান\n\n"
                        + "প্রতিদিন নতুন হাদিস নিজে থেকেই আসবে। উইজেটে ট্যাপ করলে সেদিনের পরের হাদিস দেখাবে।",
                15, false, pad / 2));

        root.addView(text("সব হাদিস", 18, true, pad));

        List<HadithRepo.Hadith> list = HadithRepo.all(this);
        for (int i = 0; i < list.size(); i++) {
            HadithRepo.Hadith h = list.get(i);
            root.addView(text(
                    (i + 1) + ". " + h.text + "\n— " + h.narrator + " | " + h.source,
                    15, false, pad));
        }

        setContentView(scroll);
    }

    private TextView text(String s, float sp, boolean bold, int topMargin) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(sp);
        if (bold) {
            tv.setTypeface(Typeface.DEFAULT_BOLD);
        }
        tv.setTextColor(0xFF1B1B1B);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = topMargin;
        tv.setLayoutParams(lp);
        return tv;
    }
}
