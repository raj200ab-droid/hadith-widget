package com.hadith.widget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

final class HadithRepo {

    static final class Hadith {
        final String text;
        final String narrator;
        final String source;

        Hadith(String text, String narrator, String source) {
            this.text = text;
            this.narrator = narrator;
            this.source = source;
        }
    }

    private static final String PREFS = "hadith_prefs";
    private static List<Hadith> cache;

    private HadithRepo() {
    }

    static synchronized List<Hadith> all(Context context) {
        if (cache != null) {
            return cache;
        }
        List<Hadith> list = new ArrayList<>();
        try (InputStream is = context.getAssets().open("hadith.json")) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            JSONArray arr = new JSONArray(new String(bos.toByteArray(), StandardCharsets.UTF_8));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                list.add(new Hadith(
                        o.getString("text"),
                        o.optString("narrator", ""),
                        o.optString("source", "")));
            }
        } catch (Exception ignored) {
            // fall through; handled by fallback below
        }
        if (list.isEmpty()) {
            list.add(new Hadith("হাদিস লোড করা যায়নি।", "", ""));
        }
        cache = list;
        return list;
    }

    /** Days since epoch in the phone's local time zone. */
    private static long today() {
        long now = System.currentTimeMillis();
        return (now + TimeZone.getDefault().getOffset(now)) / 86400000L;
    }

    static Hadith current(Context context) {
        List<Hadith> list = all(context);
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long day = today();
        int extra = (p.getLong("day", -1) == day) ? p.getInt("extra", 0) : 0;
        int idx = (int) ((day + extra) % list.size());
        return list.get(idx);
    }

    /** Called when the user taps the widget: show the next hadith for today. */
    static void next(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long day = today();
        int extra = (p.getLong("day", -1) == day) ? p.getInt("extra", 0) : 0;
        p.edit().putLong("day", day).putInt("extra", extra + 1).apply();
    }
}
